[CmdletBinding()]
param([switch]$Installer, [switch]$LockedRestore)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot -Parent
if ($env:OS -ne 'Windows_NT') { throw 'This packaging entry point requires Windows. Cross-platform compilation is also available via dotnet build SirajCAD.PlotStudio.sln.' }
Push-Location $root
try {
    $restoreArgs = @('restore', 'SirajCAD.PlotStudio.sln')
    if ($LockedRestore) { $restoreArgs += '--locked-mode' }
    & dotnet @restoreArgs
    if ($LASTEXITCODE -ne 0) { throw 'Dependency restore failed.' }
    & dotnet build SirajCAD.PlotStudio.sln -c Release --no-restore
    if ($LASTEXITCODE -ne 0) { throw 'Windows build failed.' }
    & dotnet run --project tests/SirajCAD.Core.Tests -c Release --no-build
    if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
    $bundle = Join-Path $root 'artifacts/SirajCAD.PlotStudio.bundle'
    # Only the generated bundle directory is refreshed; source DWGs are never touched.
    if (Test-Path $bundle) { Remove-Item $bundle -Recurse -Force }
    $contents = Join-Path $bundle 'Contents'
    New-Item $contents -ItemType Directory -Force | Out-Null
    Copy-Item 'installer/PackageContents.xml' $bundle
    Copy-Item 'src/SirajCAD.PlotStudio/bin/Release/net48/*.dll' $contents
    # Autodesk reference packages are compile-only. Fail if any host binary leaked into deployment.
    $hostDlls = @('AcMgd.dll','AcDbMgd.dll','AcCoreMgd.dll','AcCui.dll','AcDx.dll','AcMr.dll','AcSeamless.dll','AcTcMgd.dll','AcWindows.dll','AdUIMgd.dll','AdUiPalettes.dll','AdWindows.dll','acdbmgdbrep.dll')
    foreach ($name in $hostDlls) { if (Test-Path (Join-Path $contents $name)) { throw "Autodesk host assembly must not be redistributed: $name" } }
    $launcher = Join-Path $contents 'Launcher'
    New-Item $launcher -ItemType Directory -Force | Out-Null
    Copy-Item 'src/SirajCAD.Launcher/bin/Release/net48/SirajCAD.Launcher.exe' $launcher
    Copy-Item 'src/SirajCAD.Launcher/bin/Release/net48/SirajCAD.Launcher.exe.config' $launcher -ErrorAction SilentlyContinue
    Copy-Item 'README.md' $bundle
    Copy-Item 'docs' $bundle -Recurse
    Compress-Archive -Path $bundle -DestinationPath 'artifacts/SirajCAD-Windows-Bundle.zip' -Force
    if ($Installer) {
        $compiler = Get-Command ISCC.exe -ErrorAction SilentlyContinue
        if (-not $compiler) { throw 'Install Inno Setup 6 and add ISCC.exe to PATH, or build the .iss file using the Inno Setup GUI.' }
        & $compiler.Source 'installer/SirajCAD.iss'
        if ($LASTEXITCODE -ne 0) { throw 'Installer build failed.' }
    }
    Write-Host "Built bundle: $bundle"
    Write-Host 'Build success does not establish AutoCAD integration readiness. Complete docs/ACCEPTANCE.md on AutoCAD 2018.'
}
finally { Pop-Location }
