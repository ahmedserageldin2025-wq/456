#!/usr/bin/env python3
"""Package already-built net48 artifacts; does not claim Windows runtime validation."""
from pathlib import Path
import hashlib, shutil, zipfile

root = Path(__file__).resolve().parents[1]
artifacts = root / 'artifacts'
bundle = artifacts / 'SirajCAD.PlotStudio.bundle'
plugin = root / 'src/SirajCAD.PlotStudio/bin/Release/net48'
launcher = root / 'src/SirajCAD.Launcher/bin/Release/net48'
required = ['SirajCAD.PlotStudio.dll', 'SirajCAD.Core.dll', 'PdfSharp.dll']
for name in required:
    if not (plugin / name).is_file(): raise SystemExit(f'Missing build output: {name}')
if not (launcher / 'SirajCAD.Launcher.exe').is_file(): raise SystemExit('Missing launcher')
host = {'acmgd.dll','acdbmgd.dll','accoremgd.dll','accui.dll','acdx.dll','acmr.dll','acseamless.dll','actcmgd.dll','acwindows.dll','aduimgd.dll','aduipalettes.dll','adwindows.dll','acdbmgdbrep.dll'}
files = list(plugin.glob('*.dll'))
if any(f.name.lower() in host for f in files): raise SystemExit('Autodesk host binaries must not be packaged')
if bundle.exists(): shutil.rmtree(bundle)
contents = bundle / 'Contents'
contents.mkdir(parents=True)
for file in files: shutil.copy2(file, contents)
(contents / 'Launcher').mkdir()
for file in launcher.glob('SirajCAD.Launcher.exe*'): shutil.copy2(file, contents / 'Launcher')
shutil.copy2(root / 'installer/PackageContents.xml', bundle)
shutil.copy2(root / 'README.md', bundle)
shutil.copytree(root / 'docs', bundle / 'docs')
manifest = []
for file in sorted(bundle.rglob('*')):
    if file.is_file(): manifest.append(hashlib.sha256(file.read_bytes()).hexdigest() + '  ' + file.relative_to(bundle).as_posix())
(bundle / 'SHA256SUMS.txt').write_text('\n'.join(manifest) + '\n')
with zipfile.ZipFile(artifacts / 'SirajCAD-Windows-Bundle.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(bundle.rglob('*')):
        if file.is_file(): archive.write(file, file.relative_to(artifacts))
with zipfile.ZipFile(artifacts / 'SirajCAD-Source-1.0.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(root.rglob('*')):
        relative = file.relative_to(root)
        if file.is_file() and not any(p in {'.git','bin','obj','artifacts','.vs','__pycache__'} for p in relative.parts):
            archive.write(file, Path('SirajCAD-Source-1.0') / relative)
for name in ['SirajCAD-Windows-Bundle.zip', 'SirajCAD-Source-1.0.zip']:
    file = artifacts / name
    print(f'{name}: {file.stat().st_size} bytes; SHA256 {hashlib.sha256(file.read_bytes()).hexdigest()}')
