#!/usr/bin/env python3
"""Validate XAML wiring and generate control declarations for a C#-only compile.
This does not compile BAML or validate Windows/AutoCAD runtime behavior.
"""
import pathlib, re, xml.etree.ElementTree as ET
root = pathlib.Path(__file__).resolve().parents[1]
xaml = root / 'src/SirajCAD.PlotStudio/StudioWindow.xaml'
code = (xaml.with_suffix('.xaml.cs')).read_text()
tree = ET.parse(xaml)
x = '{http://schemas.microsoft.com/winfx/2006/xaml}Name'
names, fields = set(), []
events = {'Click', 'SelectionChanged'}
for element in tree.iter():
    kind = element.tag.split('}')[-1]
    if x in element.attrib and element.attrib[x] != 'Nav':
        name = element.attrib[x]
        if name in names: raise SystemExit(f'Duplicate control: {name}')
        names.add(name)
        fields.append(f'private System.Windows.Controls.{kind} {name};')
    for key in events:
        handler = element.attrib.get(key)
        if handler and not re.search(r'void\s+' + re.escape(handler) + r'\s*\(', code):
            raise SystemExit(f'Missing event handler: {handler}')
tabs = [e for e in tree.iter() if e.tag.endswith('}TabItem')]
if len(tabs) != 10: raise SystemExit(f'Expected ten modules; found {len(tabs)}')
output = root / 'tests/SirajCAD.SourceChecks/obj/GeneratedControls.cs'
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text('namespace SirajCAD.PlotStudio { public partial class StudioWindow { private void InitializeComponent() {}\n' + '\n'.join(fields) + '\n} }')
print(f'PASS: XML, {len(tabs)} modules, {len(names)} unique controls, event-handler wiring. Generated C#-only declarations.')
