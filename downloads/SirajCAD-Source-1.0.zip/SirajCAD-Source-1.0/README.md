# SirajCAD Plot Studio — إصدار المصدر 1.0

برنامج مكتبي أسود وذهبي لإدارة لوحات AutoCAD 2018 والطباعة الجماعية وإصدار PDF، مبني بلغة C# وواجهة WPF. يحتوي على إضافة تعمل **داخل AutoCAD** ومشغّل Windows مستقل يفتح AutoCAD ويرسل أمر `SIRAJ_PLOT`. المشغّل ليس محرّك DWG مستقلًا؛ يلزم AutoCAD 2018 مرخّص.

**حالة التسليم:** تم بناء الحل الكامل، بما فيه WPF وDLL والمشغّل، في بيئة Linux بواسطة .NET SDK ومراجع Autodesk المنشورة للإصدار 22.0. نجحت الاختبارات الآلية للمنطق وPDF. لم تُشغّل الواجهة على Windows أو الإضافة داخل AutoCAD، ولم تُختبر الطابعة أو DWG فعلي. الحزمة إصدار مرشح للتحقق، وليست إصدارًا تجاريًا معتمدًا أو موقّعًا. راجع [نتائج التحقق](docs/VALIDATION.md) و[قائمة القبول](docs/ACCEPTANCE.md).

## الوحدات العشر

| الوحدة | الوظائف الموجودة في المصدر |
|---|---|
| Dashboard | ملخص الرسم واللوحات وطابور المشروع ومسار العمل |
| Layout Manager | إنشاء ونسخ وتسمية وحذف وترتيب وتفعيل اللوحات؛ تطبيق إعدادات الصفحة ومعاينة AutoCAD |
| Smart Sheet Manager | فحص مستطيلات Polylines وحدود Blocks؛ توصية ISO؛ إنشاء Layout بنافذة عرض ملائمة ومقفلة من إطار Model Space |
| Batch Plot | استيراد ملفات ومجلدات DWG، اختيار اللوحات، منع تضارب الأسماء، طباعة فعلية أو PDF، إيقاف بين اللوحات |
| PDF Publisher | ملفات منفردة، دمج اختياري بعد نجاح المهمة، دمج يدوي بترتيب محدد وفواصل مرجعية؛ فتح PDF خارجيًا |
| Batch Processor | Purge متعدد المرور إلى نسخ DWG جديدة، بما فيها ملفات Model-only؛ لا يستبدل الأصل |
| Viewport Manager | عرض الـViewports، قفل وفك القفل، تغيير المقياس مع مراعاة وحدات الرسم |
| Preset Manager | إعدادات متعددة مسماة للطابعة والورق والأسلوب والدوران والمقياس؛ استيراد وتصدير XML |
| Quality Check & Logs | فحص توفر أجهزة الطباعة وتعيين الورق وحالة Xrefs وقفل النوافذ؛ نتائج وCSV عربي آمن للفتح في Excel |
| Settings | مجلد الإخراج، التسمية، سياسة التخطي والدمج، حفظ محلي مع نسخة احتياطية |

تفاصيل النطاق وحدوده في [المتطلبات والتغطية](docs/SRS.ar.md). وجود الشفرة لا يعني اجتياز اختبارها داخل AutoCAD.

## متطلبات Windows

- Windows 10/11 x64، وAutoCAD **2018 x64 / R22.0** مرخّص. توافق نسخة AutoCAD نفسها مع نظام Windows وتحديثاته مسؤولية تثبيت Autodesk المعتمد.
- **.NET Framework 4.8**؛ هذا تحديث مقصود عن استهداف 4.6 في المرفق لتشغيل مكتبة PDF الحديثة. يلزم اختبار هذا التكوين مع نسخة AutoCAD وتحديثاتها.
- للبناء: .NET SDK 8.0.4xx أو أحدث ضمن 8.0، واتصال NuGet. حزمة `AutoCAD.NET 22.0.0` توفر مراجع البناء فقط؛ لا تغني عن تثبيت AutoCAD ولا تُضمّن DLLs الخاصة به في الحزمة.
- لإنشاء Setup EXE: Inno Setup 6 حديث يدعم `x64compatible` و.NET 4.8؛ أضف `ISCC.exe` إلى PATH.

## البناء والتثبيت

من PowerShell داخل جذر المشروع:

```powershell
./scripts/Build-Windows.ps1 -LockedRestore
# لإنتاج برنامج التثبيت أيضًا بعد تثبيت Inno Setup:
./scripts/Build-Windows.ps1 -LockedRestore -Installer
```

يمكن استخدام `BUILD_2018.bat` بدلًا من ذلك. المخرجات:

- `artifacts/SirajCAD.PlotStudio.bundle/` — الإضافة وملحقاتها والمشغّل.
- `artifacts/SirajCAD-Windows-Bundle.zip` — الحزمة المضغوطة.
- `artifacts/SirajCAD_PlotStudio_Setup_1.0.0.exe` — يظهر فقط عند بناء Inno Setup؛ لم يتم توليده في بيئة التسليم الحالية.

للتثبيت اليدوي، أغلق AutoCAD وانسخ مجلد `.bundle` كاملًا إلى:

```text
%APPDATA%\Autodesk\ApplicationPlugins\SirajCAD.PlotStudio.bundle
```

أعد تشغيل AutoCAD واكتب `SIRAJ_PLOT`، أو افتح `Contents\Launcher\SirajCAD.Launcher.exe`. يمكن إنشاء اختصار للمشغّل. برنامج التثبيت ينشئ الاختصارات تلقائيًا عند بنائه. إذا تعذّر الاكتشاف، افحص `APPAUTOLOAD` ومواقع الثقة؛ يمكن استخدام `NETLOAD` لملف `Contents\SirajCAD.PlotStudio.dll` في موقع موثوق. أبق جميع مكتبات التبعية بجواره. لا تعطّل `SECURELOAD` أو تغيّر ملفات AutoCAD العامة لتجاوز التحميل.

## الاستخدام

1. افتح DWG واحفظه، ثم افتح البرنامج وحدّث قائمة اللوحات والأجهزة.
2. اختر جهاز PDF مثل `DWG To PDF.pc3` ومقاس الورق الصحيح وأسلوب CTB/STB المتوافق مع الرسم. المقاسات المعروضة Canonical من AutoCAD نفسه.
3. اختر اللوحات وانقر Preview قبل تطبيق الإعدادات أو النشر. `Fit` يستخدم حدود المحتوى ويُمركزها؛ عند تعطيله يُستخدم مقياس الورق المحدد. مقياس طباعة Layout المعتاد 1:1، ومقياس الـViewport منفصل.
4. للمشروع الكامل أضف DWGs أو مجلدًا في Batch Plot. حدّد اللوحات، وافحص مسارات المخرجات، ثم انشر. الإيقاف يعمل بين اللوحات ولا يقطع محرّك AutoCAD أثناء اللوحة الحالية.
5. من Settings يمكن تفعيل دمج المهمة تلقائيًا. لا يصدر ملف مجمع إذا فشلت أو أُلغيت أي لوحة. ملفات PDF الموجودة المتخطاة تُستخدم في الدمج ويُفحص تركيبها بواسطة مكتبة PDF؛ مسؤولية صلاحية محتواها للمشروع تقع على المراجع.
6. للطباعة الفعلية اختر طابعة Windows/PC3 مادية؛ سيطلب البرنامج تأكيدًا. المحركات الافتراضية غير المخصصة لـPDF قد تعرض حوارات حفظ.
7. لمعالجة DWG افتح Batch Processor بعد الاستيراد. يتم قراءة النسخ المحفوظة على القرص وكتابة `_clean.dwg` في مجلد الإخراج. التغييرات غير المحفوظة في AutoCAD لا تدخل هذه المعالجة.

الإعدادات في `%APPDATA%\SirajCAD\settings.xml`، والنسخة السابقة في `settings.xml.bak`. لا يحتاج البرنامج إلى مفاتيح API أو اتصال شبكي للتشغيل المحلي.

## نقاط المراجعة الهندسية

التعرف على الإطارات قائم على الهندسة وحدود الكتل، وليس فهمًا تلقائيًا لمحتوى Title Blocks. الإطارات المائلة تُقاس بحدودها المحاذية للمحاور. إنشاء Layout منها يستخدم عرض/ارتفاع Viewport يدخلهما المستخدم وفق مساحة الورق القابلة للطباعة، مع هامش مشاهدة 2%، ولا ينشئ Title Block ورقيًا جديدًا. راجع الوحدات والاتجاه ومساحة الطباعة في المعاينة.

فحص الجودة ليس `AUDIT` لإصلاح بنية DWG. لا يتضمن الإصدار إصلاحًا آليًا للرسومات التالفة أو ربط Xrefs أو تحرير خصائص Title Blocks أو محرك عرض PDF مدمجًا. لا تُرسل ملفات كبيرة للطباعة الإنتاجية قبل اجتياز قائمة القبول على نسخ اختبارية.

## الاختبارات والبنية

```text
src/SirajCAD.Core/           منطق المهام والتسمية والتقارير والإعدادات وPDF
src/SirajCAD.PlotStudio/     واجهة WPF وعمليات AutoCAD 2018
src/SirajCAD.Launcher/       مشغّل Windows عبر AutoCAD COM
installer/                  تعريف AutoLoader وInno Setup
scripts/                    أدوات البناء والفحص
 tests/SirajCAD.Core.Tests/  اختبارات تنفيذية دون AutoCAD
 tests/SirajCAD.SourceChecks/ فحص C# إضافي بمراجع Autodesk الحقيقية
```

```bash
dotnet restore SirajCAD.PlotStudio.sln --locked-mode
dotnet build SirajCAD.PlotStudio.sln -c Release --no-restore
dotnet run --project tests/SirajCAD.Core.Tests -c Release --no-build
python3 scripts/check-source.py
dotnet restore tests/SirajCAD.SourceChecks --locked-mode
dotnet build tests/SirajCAD.SourceChecks -c Release --no-restore
```

توجد CI للبناء والاختبارات على Windows وLinux. لم يتم تشغيل خدمة GitHub Actions ضمن هذه الجلسة. راجع تراخيص التبعيات قبل التوزيع؛ PDFsharp تحت MIT، ومراجع Autodesk تخضع لشروط Autodesk. لا تتضمن الحزمة AutoCAD أو ترخيصه أو ملف توقيع رقمي.
