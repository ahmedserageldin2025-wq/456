# Validation evidence — 2026-10-27

Environment: Linux x64; .NET SDK **8.0.427**; target application **.NET Framework 4.8 / x64**, reference packages **AutoCAD.NET 22.0.0** (AutoCAD 2018). Runtime Windows and AutoCAD were not available.

## Passed

- Full `SirajCAD.PlotStudio.sln` Release build: **0 errors, 0 warnings**. This compiled WPF XAML/BAML and its code-behind, Core, the Windows launcher EXE and the executable test project. It was a real application build, not just a generated-control source check.
- Independent C# API compilation check against Autodesk 2018 references; generated control declarations are only for this supplementary check.
- XAML structural/wiring check: ten modules, unique named controls, event handlers present.
- Core test runner: **12 tests passed, 0 failed**. Covers Windows-safe names and collisions, immutable planning, ISO geometry and invalid scales, XML round-trip/atomic backup/DTD rejection, Unicode/CSV safety, batch failure isolation and skipped states, cancellation, reentrant-step protection, and PDF merge page order/sizes/bookmarks/no-overwrite/failure cleanup.
- PDF tests created actual input PDFs, merged and reopened them using PDFsharp; they did not exercise AutoCAD-generated PDF graphics.
- Dependency locks saved for all projects. Release bundle checks ensure Autodesk host DLLs are absent and all required application binaries present.

## Not executed

- Windows desktop UI rendering and COM launcher connection to AutoCAD.
- Actual SIRAJ_PLOT registration/loading and assembly binding in AutoCAD 2018.
- Real DWG layout edits, viewport creation/scales, purge fidelity, quality checks, preview rendering and printing.
- AutoCAD PC3/CTB/STB behavior, generated CAD PDF accuracy, and a physical printer.
- Inno Setup compilation/execution and code signing. The supplied installer is source; no Setup EXE is claimed.
- GitHub Actions execution and environment publication/restoration in a new task.

An early compile caught the original ambiguous `PlotType` reference; the source now explicitly binds the database-services enum. The malformed-PDF test was corrected to assert PDFsharp's actual `InvalidOperationException`, and the full test runner passed afterward. No assertion was removed to obtain a pass.

Use ACCEPTANCE.md before approving an engineering production release. Build success establishes compilation, not host behavior or print accuracy.
