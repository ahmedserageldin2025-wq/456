# Windows / AutoCAD 2018 acceptance checklist

Status: **not executed in the delivery environment**. Record Windows version, AutoCAD 2018 build/update, .NET Framework version, printer/driver, PC3, CTB/STB, drawing units and measured outputs with every run. Use disposable DWGs and known paper dimensions. Do not mark a row passed from source inspection alone.

| Check | Expected result |
|---|---|
| Install per-user bundle, restart AutoCAD | SIRAJ_PLOT autoloads only on R22.0 x64; dependency DLLs resolve |
| Desktop launcher: attach and new instance | Uses AutoCAD.Application.22; opens selected DWG; busy/absent COM server produces a useful error |
| Layout create/clone/rename/delete/reorder/activate | Correct tabs change; Model cannot be renamed/deleted; cancel leaves drawing unchanged |
| Switch active drawing after populating layouts/viewports/frames | Stale selections are rejected; refresh allows operations on new drawing |
| Device/media/style mismatch | Invalid device, media and incompatible CTB/STB fail visibly; no substitute paper is silently accepted |
| Fit / 1:1 / rotated page setup | Print preview and measured PDF agree with paper/scale; viewport denominator is independent of page scale |
| Native AutoCAD preview | Correct sheet renders; closing preview restores active layout and BACKGROUNDPLOT |
| Frame scan: rectangular polyline, curved polyline, block, rotated frame | Rectangles and block candidates appear; curved polylines do not; bounds/units and candidate caveats are clear |
| Frame-to-layout | Model frame creates one locked viewport; chosen dimensions fit printable area; failed setup removes only the new layout |
| Viewport scale and locks | Selected floating viewports change; paper-space viewport #1 remains untouched; non-finite scales rejected |
| Open and unopened DWGs in the same batch | Open drawings retain unsaved in-memory edits and stay open; temporary drawings close without saving; previous active document restored |
| PDF output | Correct media, page size, orientation, lineweights, fonts, image/Xref content, scale and page count in an independent viewer |
| Physical printer | Confirmation appears, one copy per selected sheet, accurate output; driver failure logged; virtual drivers may require input |
| Duplicate sanitized names / existing outputs | Collisions rejected before job; existing files never replaced; skipped rows recorded independently |
| Stop during long batch; close studio during job | Current sheet finishes; remaining rows Cancelled; no nested batch; window can close after completion |
| Missing/locked/bad/password DWG or failed PC3 | Failed row recorded; next row still executes; temporary outputs removed |
| Automatic combined issue | All completed inputs merge in selected order with file bookmarks; failed/cancelled input suppresses combined issue |
| Manual PDF merge | Reordering and removing inputs reflected; Arabic filenames; encrypted/corrupt PDFs fail without partial output |
| Purge model-only and layout DWGs | New _clean.dwg opens in AutoCAD 2018; intended geometry retained; originals byte-identical; existing copies not replaced |
| Quality inspection | Missing device, unset paper, unresolved Xref, unlocked viewport produce corresponding findings; not represented as AUDIT |
| Settings round-trip and corruption | Presets survive restart and import/export; previous settings retained as .bak; corrupted XML reported |
| CSV and report failure | Distinct results and Unicode readable; unwritable output directory blocks job before printing; later report write failure recoverable via Export |
| Large representative project | Measure time/memory for representative sheets and files; host remains usable between sheets; no leaked documents/plot engine |
| Shared .NET dependencies with other plugins | No assembly binding errors with actual office plugins; test on clean and production-like AutoCAD profiles |

Release only after all required rows pass and any defects have a recorded disposition. Installer EXE compilation, digital signing and SmartScreen reputation are separate packaging/release activities.
