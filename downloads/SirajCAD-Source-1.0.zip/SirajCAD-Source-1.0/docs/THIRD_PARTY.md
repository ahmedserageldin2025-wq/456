# Third-party components

AutoCAD.NET 22.0.0 is used only as a build-time reference. Autodesk host binaries are excluded from the bundle. AutoCAD itself requires a separate licensed installation.

Runtime libraries are restored from NuGet with content hashes recorded in packages.lock.json. Applicable license texts and notices are in licenses/. PDFsharp is MIT licensed. The original user-provided application archive did not state a project-wide license; this delivery does not invent redistribution rights for it.

| Package | Version | License metadata |
|---|---|---|
| PDFsharp | 6.2.0 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Bcl.AsyncInterfaces | 8.0.0 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.DependencyInjection | 8.0.1 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.DependencyInjection.Abstractions | 8.0.2 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.Logging | 8.0.1 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.Logging.Abstractions | 8.0.2 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.Options | 8.0.2 | MIT; https://licenses.nuget.org/MIT |
| Microsoft.Extensions.Primitives | 8.0.0 | MIT; https://licenses.nuget.org/MIT |
| System.Buffers | 4.5.1 | https://github.com/dotnet/corefx/blob/master/LICENSE.TXT |
| System.Diagnostics.DiagnosticSource | 8.0.1 | MIT; https://licenses.nuget.org/MIT |
| System.Memory | 4.5.5 | https://github.com/dotnet/corefx/blob/master/LICENSE.TXT |
| System.Numerics.Vectors | 4.5.0 | https://github.com/dotnet/corefx/blob/master/LICENSE.TXT |
| System.Runtime.CompilerServices.Unsafe | 6.0.0 | MIT; https://licenses.nuget.org/MIT |
| System.Security.Cryptography.Pkcs | 8.0.1 | MIT; https://licenses.nuget.org/MIT |
| System.Threading.Tasks.Extensions | 4.5.4 | https://github.com/dotnet/corefx/blob/master/LICENSE.TXT |
| System.ValueTuple | 4.5.0 | https://github.com/dotnet/corefx/blob/master/LICENSE.TXT |
