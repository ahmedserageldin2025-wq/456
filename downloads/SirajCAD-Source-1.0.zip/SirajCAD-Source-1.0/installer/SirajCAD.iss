#define MyAppName "SirajCAD Plot Studio"
#define MyAppVersion "1.0.0"
[Setup]
AppId={{9D7E4D79-321D-4C61-83AC-03E9E0462C8B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={userappdata}\Autodesk\ApplicationPlugins\SirajCAD.PlotStudio.bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputDir=..\artifacts
OutputBaseFilename=SirajCAD_PlotStudio_Setup_1.0.0
Compression=lzma
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
UninstallDisplayName={#MyAppName}
[Files]
Source: "..\artifacts\SirajCAD.PlotStudio.bundle\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{userdesktop}\SirajCAD Plot Studio"; Filename: "{app}\Contents\Launcher\SirajCAD.Launcher.exe"
Name: "{userprograms}\SirajCAD Plot Studio"; Filename: "{app}\Contents\Launcher\SirajCAD.Launcher.exe"
[Code]
function InitializeSetup(): Boolean;
begin
  Result := IsDotNetInstalled(net48, 0);
  if not Result then MsgBox('Install Microsoft .NET Framework 4.8 before installing SirajCAD. AutoCAD 2018 x64 is also required.', mbError, MB_OK);
end;
