@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0scripts\Build-Windows.ps1" %*
exit /b %ERRORLEVEL%
