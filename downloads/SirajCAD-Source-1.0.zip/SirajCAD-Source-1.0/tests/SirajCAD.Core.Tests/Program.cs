using SirajCAD.Core;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

int passed = 0, failed = 0;
string root = Path.Combine(Path.GetTempPath(), "siraj-tests-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
void Throws<T>(Action action) where T : Exception { try { action(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }
void Test(string name, Action action) { try { action(); passed++; Console.WriteLine("PASS " + name); } catch (Exception e) { failed++; Console.WriteLine("FAIL " + name + ": " + e); } }
try
{
    Test("Windows filenames: reserved devices, traversal, invalid chars and trailing dots", () => {
        Check(JobPlanner.SafeName("CON.pdf") == "_CON.pdf", "Reserved device");
        Check(JobPlanner.SafeName("Plan/A:1? . ") == "Plan_A_1_", "Windows invalid characters");
        Check(JobPlanner.SafeName("../Plan") == ".._Plan", "Separator escaped");
        Check(JobPlanner.SafeName("لوحة ١") == "لوحة ١", "Arabic preserved");
    });
    Test("Case-insensitive and sanitization output collisions rejected", () => {
        Throws<InvalidOperationException>(() => JobPlanner.Plan(new[] { new SheetJob { Drawing="a.dwg",Layout="A/B" }, new SheetJob { Drawing="b.dwg",Layout="a:b" } },root,false));
        Throws<InvalidOperationException>(() => JobPlanner.Plan(new[] { new SheetJob { Drawing="one/a.dwg",Layout="S1" }, new SheetJob { Drawing="two/a.dwg",Layout="S1" } },root,true));
    });
    Test("Planner snapshots input, preserves order and validates empty jobs", () => {
        var sheet = new SheetJob { Drawing="A.dwg", Layout="Sheet1" };
        var jobs = JobPlanner.Plan(new[] {sheet},root,true); sheet.Layout="Changed";
        Check(jobs[0].Layout=="Sheet1" && Path.GetFileName(jobs[0].Output)=="A_Sheet1.pdf","Snapshot");
        Throws<InvalidOperationException>(()=>JobPlanner.Plan(Array.Empty<SheetJob>(),root,true));
        Throws<ArgumentException>(()=>JobPlanner.Plan(new[]{sheet},"relative",true));
    });
    Test("ISO recommendation uses real dimensions, rotation, limits and unit validation", () => {
        Check(SheetGeometry.RecommendIso(420,297)=="A3","Landscape A3");
        Check(SheetGeometry.RecommendIso(594,841)=="A1","A1");
        Check(SheetGeometry.RecommendIso(2000,1200)=="Custom","Custom size");
        Throws<ArgumentException>(()=>SheetGeometry.RecommendIso(double.NaN,10));
        Throws<ArgumentException>(()=>SheetGeometry.RecommendIso(-1,10));
    });
    Test("Preset rejects non-finite and invalid scales", () => {
        foreach(double d in new[]{0d,-1d,double.PositiveInfinity,double.NaN}) Throws<ArgumentException>(()=>new PlotPreset {ScaleDenominator=d}.Validate());
        new PlotPreset().Validate();
    });
    Test("Settings round-trip, atomic replacement and backup", () => {
        string file=Path.Combine(root,"config","settings.xml");
        var s=new StudioSettings {OutputFolder=root}; s.Presets.Add(new PlotPreset {Name="مقياس ١٠٠",ScaleDenominator=100,Landscape=true});
        XmlStore.Save(file,s); var read=XmlStore.Load<StudioSettings>(file);
        Check(read.Presets[0].Name=="مقياس ١٠٠" && read.Presets[0].Landscape,"Serialization");
        s.OutputFolder=root+"-new"; XmlStore.Save(file,s);
        Check(File.Exists(file+".bak") && XmlStore.Load<StudioSettings>(file+".bak").OutputFolder==root,"Backup");
        Check(!Directory.GetFiles(Path.GetDirectoryName(file),"*.tmp").Any(),"Temp cleanup");
    });
    Test("Corrupt and entity-expansion XML rejected without modifying input", () => {
        string file=Path.Combine(root,"bad.xml");
        string bad="<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]><StudioSettings><OutputFolder>&e;</OutputFolder></StudioSettings>";
        File.WriteAllText(file,bad); Throws<InvalidOperationException>(()=>XmlStore.Load<StudioSettings>(file));
        Check(File.ReadAllText(file)==bad,"Preserved input");
    });
    Test("CSV escapes quotes, multiline values and spreadsheet formulas", () => {
        string file=Path.Combine(root,"log.csv");
        ReportWriter.Save(file,new[]{new JobRecord {Drawing="=HYPERLINK(\"a\")",Layout="a,\"b\"\nc",Status="Failed",Error="تجربة"}});
        string text=File.ReadAllText(file);
        Check(text.Contains("\"'=HYPERLINK(\"\"a\"\")\"") && text.Contains("a,\"\"b\"\"\nc") && text.Contains("تجربة"),"CSV safety and Unicode");
    });
    Test("Batch isolates failures, preserves skipped results and completes exactly once", () => {
        var records = Enumerable.Range(0,3).Select(i=>new JobRecord { Status="Queued" }).ToArray();
        int executed=0;
        var session=new BatchSession(new[] {
            new BatchTask {Record=records[0],Work=()=>{executed++;throw new IOException("Printer unavailable");}},
            new BatchTask {Record=records[1],Work=()=>{executed++;records[1].Status="Skipped";}},
            new BatchTask {Record=records[2],Work=()=>executed++}
        });
        while(session.IsRunning) session.Step(); session.Step();
        Check(executed==3 && session.CompletedCount==3,"Exactly once");
        Check(records[0].Status=="Failed" && records[0].Error=="Printer unavailable" && records[1].Status=="Skipped" && records[2].Status=="Succeeded","Distinct outcomes");
    });
    Test("Batch stop between sheets marks all unrun tasks cancelled", () => {
        var records=Enumerable.Range(0,3).Select(i=>new JobRecord {Status="Queued"}).ToArray();
        int executed=0;
        var session=new BatchSession(records.Select(r=>new BatchTask {Record=r,Work=()=>executed++}));
        session.Step(); session.Stop(); session.Step();
        Check(executed==1 && !session.IsRunning && records[0].Status=="Succeeded" && records.Skip(1).All(r=>r.Status=="Cancelled"),"Cancel outcomes");
    });
    Test("Reentrant batch Step cannot start the next sheet during a running task", () => {
        BatchSession session=null; int executed=0;
        session=new BatchSession(new[]{new BatchTask {Record=new JobRecord(),Work=()=>{session.Step();executed++;}},new BatchTask {Record=new JobRecord(),Work=()=>executed++}});
        session.Step(); Check(executed==1 && session.IsRunning,"No nested execution");
        session.Step(); Check(executed==2 && !session.IsRunning,"Resumed");
    });
    Test("PDF merge: ordered pages, sizes, bookmarks, no overwrite and cleanup", () => {
        string a=Path.Combine(root,"A.pdf"),b=Path.Combine(root,"B.pdf"),output=Path.Combine(root,"Merged.pdf");
        using(var doc=new PdfDocument()) {var p=doc.AddPage(); p.Width=PdfSharp.Drawing.XUnit.FromPoint(210); p.Height=PdfSharp.Drawing.XUnit.FromPoint(300); doc.Save(a);}
        using(var doc=new PdfDocument()) {var p=doc.AddPage(); p.Width=PdfSharp.Drawing.XUnit.FromPoint(420); p.Height=PdfSharp.Drawing.XUnit.FromPoint(600); doc.AddPage(); doc.Save(b);}
        Check(PdfPublisher.Merge(new[]{a,b},output)==3,"Page count");
        using(var doc=PdfReader.Open(output,PdfDocumentOpenMode.Import)) {Check(doc.PageCount==3,"Reopened count");Check(Math.Abs(doc.Pages[0].Width.Point-210)<0.1 && Math.Abs(doc.Pages[1].Width.Point-420)<0.1,"Order and sizes");}
        using(var doc=PdfReader.Open(output,PdfDocumentOpenMode.Modify)) Check(doc.Outlines.Count==2 && doc.Outlines[0].Title=="A" && doc.Outlines[1].Title=="B","Bookmarks");
        byte[] original=File.ReadAllBytes(output); Throws<IOException>(()=>PdfPublisher.Merge(new[]{a},output));
        Check(original.SequenceEqual(File.ReadAllBytes(output)),"No overwrite");
        string broken=Path.Combine(root,"bad.pdf"); File.WriteAllText(broken,"not a PDF");
        string failedOutput=Path.Combine(root,"failed.pdf");
        bool rejected=false; try { PdfPublisher.Merge(new[]{a,broken},failedOutput); } catch (InvalidOperationException) { rejected=true; }
        Check(rejected,"Invalid PDF rejected");
        Check(!File.Exists(failedOutput) && !Directory.GetFiles(root,"*.tmp").Any(),"Failed merge cleanup");
    });
}
finally {Directory.Delete(root,true);}
Console.WriteLine($"Results: {passed} passed, {failed} failed");
return failed==0?0:1;
