using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SirajCAD.Launcher
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            var form = new Form { Text = "SirajCAD Plot Studio", Width = 620, Height = 340, StartPosition = FormStartPosition.CenterScreen, BackColor = Color.FromArgb(19, 22, 28), ForeColor = Color.White, Font = new Font("Segoe UI", 11), FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false };
            var title = new Label { Text = "SIRAJCAD / PLOT STUDIO", ForeColor = Color.FromArgb(217, 185, 119), Font = new Font("Segoe UI", 21), Left = 30, Top = 30, AutoSize = true };
            var description = new Label { Text = "AutoCAD 2018 • Windows x64\nOpen the studio in AutoCAD, or choose a DWG first.\nInstall the SirajCAD bundle before launching.", Left = 32, Top = 90, Width = 550, Height = 90 };
            var launch = new Button { Text = "Open Studio", Left = 32, Top = 200, Width = 200, Height = 44, BackColor = Color.FromArgb(89, 74, 47) };
            var browse = new Button { Text = "Choose DWG…", Left = 250, Top = 200, Width = 200, Height = 44, BackColor = Color.FromArgb(42, 48, 57) };
            Action<string> open = file =>
            {
                launch.Enabled = browse.Enabled = false;
                try
                {
                    object instance;
                    try { instance = Marshal.GetActiveObject("AutoCAD.Application.22"); }
                    catch (COMException)
                    {
                        var type = Type.GetTypeFromProgID("AutoCAD.Application.22");
                        if (type == null) throw new InvalidOperationException("AutoCAD 2018 is not registered. Install and launch licensed AutoCAD 2018 first.");
                        instance = Activator.CreateInstance(type);
                    }
                    dynamic acad = instance;
                    acad.Visible = true;
                    if (!string.IsNullOrEmpty(file)) acad.Documents.Open(file, false);
                    if (acad.Documents.Count == 0) acad.Documents.Add();
                    acad.ActiveDocument.SendCommand("SIRAJ_PLOT\n");
                    description.Text = "Studio command sent to AutoCAD 2018.\nIf the command is unknown, verify the installed bundle\nand AutoCAD trusted locations. If AutoCAD is busy, retry.";
                }
                catch (Exception ex) { MessageBox.Show(form, ex.Message, "SirajCAD", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                finally { launch.Enabled = browse.Enabled = true; }
            };
            launch.Click += (s, e) => open(null);
            browse.Click += (s, e) => { using (var dialog = new OpenFileDialog { Filter = "AutoCAD drawing|*.dwg" }) if (dialog.ShowDialog(form) == DialogResult.OK) open(dialog.FileName); };
            form.Controls.AddRange(new Control[] { title, description, launch, browse });
            Application.Run(form);
        }
    }
}
