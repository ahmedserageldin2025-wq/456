using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using Microsoft.VisualBasic;
using Microsoft.Win32;
using SirajCAD.Core;
using Forms = System.Windows.Forms;

namespace SirajCAD.PlotStudio
{
    public class PlotQueueItem : INotifyPropertyChanged
    {
        private bool selected = true;
        private string status = "Queued";
        public string FilePath { get; set; }
        public string FileName => Path.GetFileName(FilePath);
        public string Layout { get; set; }
        public bool Selected { get => selected; set { selected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Selected))); } }
        public string Status { get => status; set { status = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Status))); } }
        public event PropertyChangedEventHandler PropertyChanged;
    }
    public partial class StudioWindow : Window
    {
        private readonly ObservableCollection<PlotQueueItem> queue = new ObservableCollection<PlotQueueItem>();
        private readonly ObservableCollection<string> drawings = new ObservableCollection<string>();
        private readonly ObservableCollection<JobRecord> logs = new ObservableCollection<JobRecord>();
        private readonly ObservableCollection<string> pdfs = new ObservableCollection<string>();
        private readonly CadJobRunner runner = new CadJobRunner();
        private StudioSettings settings = new StudioSettings();
        private List<JobRecord> lastJob = new List<JobRecord>();
        private Autodesk.AutoCAD.ApplicationServices.Document frameDocument;
        private Autodesk.AutoCAD.ApplicationServices.Document sheetDocument;
        private Autodesk.AutoCAD.ApplicationServices.Document viewportDocument;
        private readonly string settingsFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SirajCAD", "settings.xml");
        public StudioWindow()
        {
            InitializeComponent();
            ProcessorList.ItemsSource = drawings; QueueGrid.ItemsSource = queue; LogGrid.ItemsSource = logs; PdfList.ItemsSource = pdfs;
            SettingsPath.Text = settingsFile;
            FolderBox.Text = settings.OutputFolder;
            Loaded += (s, e) =>
            {
                Run(() => { settings = XmlStore.Load<StudioSettings>(settingsFile); ValidateSettings(settings); ApplySettings(); });
                Run(Refresh); Run(LoadDevices);
            };
            Closing += (s, e) => { if (runner.IsRunning) { runner.Stop(); e.Cancel = true; StatusText.Text = "Stop requested. Close the window after the current sheet finishes."; } };
        }
        private void Run(Action action)
        {
            if (runner.IsRunning) { StatusText.Text = "A job is running. Stop it before changing the project."; return; }
            try { action(); }
            catch (Exception ex) { StatusText.Text = "Error: " + ex.Message; MessageBox.Show(this, ex.Message, "SirajCAD", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }
        private void Refresh()
        {
            var sheets = CadEngine.GetSheets();
            SheetList.ItemsSource = sheets;
            sheetDocument = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            DashboardText.Text = Path.GetFileName(CadEngine.CurrentDocumentFile()) + "\n" + sheets.Count(s => !s.IsModel) + " paper layouts • " + queue.Select(x => x.FilePath).Distinct(StringComparer.OrdinalIgnoreCase).Count() + " queued drawings • " + queue.Count + " queued sheets";
            StatusText.Text = "Loaded " + sheets.Count + " layouts, including Model.";
        }
        private static double Positive(string text)
        {
            double value;
            if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0 || double.IsNaN(value) || double.IsInfinity(value)) throw new ArgumentException("Enter a positive number using a decimal point.");
            return value;
        }
        private PlotPreset CurrentPreset()
        {
            var p = new PlotPreset { Name = string.IsNullOrWhiteSpace(PresetName.Text) ? "Default" : PresetName.Text.Trim(), Device = DeviceBox.Text.Trim(), Media = MediaPicker.Text.Trim(), Style = StyleBox.Text.Trim(), Fit = FitCheck.IsChecked == true, Landscape = LandscapeCheck.IsChecked == true, ScaleDenominator = Positive(PrintScale.Text) };
            p.Validate(); return p;
        }
        private List<SheetRow> SelectedSheets()
        {
            EnsureSheetDocument();
            var rows = SheetList.SelectedItems.Cast<SheetRow>().Where(s => !s.IsModel).ToList();
            if (rows.Count == 0) throw new InvalidOperationException("Select paper-space layouts. Model-space publishing is not included in this workflow.");
            return rows;
        }
        private void EnsureSheetDocument()
        {
            if (!ReferenceEquals(sheetDocument, Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument)) throw new InvalidOperationException("Active drawing changed. Refresh the layout list first.");
        }
        private string Selected { get { EnsureSheetDocument(); return (SheetList.SelectedItem as SheetRow)?.Name; } }
        private string Ask(string label, string value = "") => Interaction.InputBox(label, "SirajCAD", value).Trim();
        private void LoadDevices()
        {
            var current = DeviceBox.Text;
            var devices = CadEngine.GetPlotDevices();
            DeviceBox.ItemsSource = devices;
            DeviceBox.Text = devices.Contains(current) ? current : devices.FirstOrDefault(d => d.Equals("DWG To PDF.pc3", StringComparison.OrdinalIgnoreCase)) ?? devices.FirstOrDefault() ?? "";
            LoadMedia();
        }
        private void LoadMedia()
        {
            var text = MediaPicker.Text;
            if (string.IsNullOrWhiteSpace(DeviceBox.Text)) return;
            MediaPicker.ItemsSource = CadEngine.GetMedia(DeviceBox.Text.Trim());
            MediaPicker.Text = text;
        }
        private void DeviceBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MediaPicker == null || !IsLoaded || runner.IsRunning) return;
            Dispatcher.BeginInvoke(new Action(() => Run(LoadMedia)));
        }
        private void Devices_Click(object sender, RoutedEventArgs e) => Run(LoadDevices);
        private void Refresh_Click(object sender, RoutedEventArgs e) => Run(Refresh);
        private void New_Click(object sender, RoutedEventArgs e) => Run(() => { var name = Ask("New layout name", "Sheet-01"); if (name.Length > 0) { CadEngine.CreateLayout(name); Refresh(); } });
        private void Duplicate_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected == null || Selected == "Model") return; var name = Ask("Copy layout as", Selected + "-Copy"); if (name.Length > 0) { CadEngine.CloneLayout(Selected, name); Refresh(); } });
        private void Rename_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected == null || Selected == "Model") return; var name = Ask("Rename layout", Selected); if (name.Length > 0 && name != Selected) { CadEngine.RenameLayout(Selected, name); Refresh(); } });
        private void Delete_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected == null || Selected == "Model") return; if (MessageBox.Show(this, "Delete layout " + Selected + "?", "Delete layout", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes) { CadEngine.DeleteLayout(Selected); Refresh(); } });
        private void Up_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected != null) { CadEngine.MoveLayout(Selected, -1); Refresh(); } });
        private void Down_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected != null) { CadEngine.MoveLayout(Selected, 1); Refresh(); } });
        private void Activate_Click(object sender, RoutedEventArgs e) => Run(() => { if (Selected != null) CadEngine.SetCurrentLayout(Selected); });
        private void ApplySetup_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var rows = SelectedSheets(); var preset = CurrentPreset();
            if (MessageBox.Show(this, "Modify page setup in memory for " + rows.Count + " layouts? Save the DWG manually to keep changes.", "Page setup", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            foreach (var row in rows) CadEngine.ApplyPreset(row.Name, preset);
            StatusText.Text = "Page setup applied. Save DWG to retain changes.";
        });
        private void Preview_Click(object sender, RoutedEventArgs e) => Run(() => { var row = SelectedSheets().First(); CadEngine.PlotSheet(row.Name, null, CurrentPreset(), false, true); });
        private void Folder_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            using (var d = new Forms.FolderBrowserDialog()) { if (Directory.Exists(FolderBox.Text)) d.SelectedPath = FolderBox.Text; if (d.ShowDialog() == Forms.DialogResult.OK) FolderBox.Text = d.SelectedPath; }
        });
        private void AddDrawing(string file)
        {
            file = Path.GetFullPath(file);
            if (drawings.Any(x => string.Equals(x, file, StringComparison.OrdinalIgnoreCase))) return;
            // Open drawings use their current in-memory layout list so unsaved changes remain visible.
            var active = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument?.Name;
            var names = string.Equals(active, file, StringComparison.OrdinalIgnoreCase) ? CadEngine.GetSheets().Where(x => !x.IsModel).Select(x => x.Name).ToArray() : CadEngine.ListLayoutsForFile(file);
            drawings.Add(file);
            foreach (var layout in names) queue.Add(new PlotQueueItem { FilePath = file, Layout = layout });
            QueueSummary.Text = queue.Count + " sheets queued.";
            if (names.Length == 0) StatusText.Text = "No paper layouts in " + Path.GetFileName(file);
        }
        private void AddFiles_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var d = new OpenFileDialog { Filter = "AutoCAD drawings|*.dwg", Multiselect = true };
            if (d.ShowDialog(this) == true) ImportDrawings(d.FileNames);
        });
        private void ImportDrawings(IEnumerable<string> files)
        {
            var errors = new List<string>();
            foreach (var file in files) { try { AddDrawing(file); } catch (Exception ex) { errors.Add(file + ": " + ex.Message); } }
            if (errors.Count > 0) throw new InvalidOperationException(string.Join("\n", errors));
        }
        private void AddFolder_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            using (var d = new Forms.FolderBrowserDialog())
                if (d.ShowDialog() == Forms.DialogResult.OK) ImportDrawings(Directory.GetFiles(d.SelectedPath, "*.dwg", RecursiveCheck.IsChecked == true ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly).OrderBy(x => x, StringComparer.OrdinalIgnoreCase));
        });
        private void ClearQueue_Click(object sender, RoutedEventArgs e) => Run(() => { queue.Clear(); drawings.Clear(); QueueSummary.Text = "Queue cleared."; });
        private void AllQueue_Click(object sender, RoutedEventArgs e) => Run(() => { foreach (var q in queue) q.Selected = true; });
        private void NoneQueue_Click(object sender, RoutedEventArgs e) => Run(() => { foreach (var q in queue) q.Selected = false; });
        private List<PlotQueueItem> SelectedQueue()
        {
            QueueGrid.CommitEdit(DataGridEditingUnit.Cell, true); QueueGrid.CommitEdit(DataGridEditingUnit.Row, true);
            var selected = queue.Where(x => x.Selected).ToList();
            if (selected.Count == 0) throw new InvalidOperationException("Select queued sheets first.");
            foreach (var q in selected) if (!File.Exists(q.FilePath)) throw new FileNotFoundException("DWG missing", q.FilePath);
            return selected;
        }
        private void ValidateQueue_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var rows = SelectedQueue(); CurrentPreset();
            var plan = JobPlanner.Plan(rows.Select(q => new SheetJob { Drawing = q.FilePath, Layout = q.Layout }), FolderBox.Text.Trim(), NamingBox.SelectedIndex == 0);
            QueueSummary.Text = plan.Count + " output paths validated. Device/media/styles are checked by AutoCAD at plot time.";
        });
        private void StartBatch_Click(object sender, RoutedEventArgs e) => Run(() => StartPlot(SelectedQueue(), true));
        private void PrintBatch_Click(object sender, RoutedEventArgs e) => Run(() => StartPlot(SelectedQueue(), false));
        private void Publish_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            string file = CadEngine.CurrentDocumentFile();
            StartPlot(SelectedSheets().Select(s => new PlotQueueItem { FilePath = file, Layout = s.Name }).ToList(), true);
        });
        private void StartPlot(List<PlotQueueItem> rows, bool toFile)
        {
            var preset = CurrentPreset();
            if (toFile && preset.Device.IndexOf("PDF", StringComparison.OrdinalIgnoreCase) < 0) throw new InvalidOperationException("Select an AutoCAD PDF PC3 device for PDF publishing.");
            if (!toFile && MessageBox.Show(this, "Send " + rows.Count + " sheets to " + preset.Device + "? This can consume paper. File-based drivers may show prompts; choose a physical printer.", "Print", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            var plan = JobPlanner.Plan(rows.Select(q => new SheetJob { Drawing = q.FilePath, Layout = q.Layout }), FolderBox.Text.Trim(), NamingBox.SelectedIndex == 0);
            bool skip = SkipExisting.IsChecked == true;
            var tasks = new List<CadTask>();
            for (int i = 0; i < plan.Count; i++)
            {
                var job = plan[i]; var row = rows[i];
                var record = new JobRecord { Drawing = job.Drawing, Layout = job.Layout, Output = toFile ? job.Output : preset.Device, Status = "Queued" };
                tasks.Add(new CadTask { Record = record, SetStatus = s => row.Status = s, Work = () =>
                {
                    if (!toFile) { CadEngine.PlotExternalSheet(job.Drawing, job.Layout, null, preset, false); return; }
                    if (File.Exists(job.Output)) { if (skip) { record.Status = "Skipped"; return; } throw new IOException("Output exists: " + job.Output); }
                    string temp = Path.Combine(Path.GetDirectoryName(job.Output), ".siraj-" + Guid.NewGuid().ToString("N") + ".pdf");
                    try
                    {
                        CadEngine.PlotExternalSheet(job.Drawing, job.Layout, temp, preset, true);
                        using (var stream = File.OpenRead(temp))
                        {
                            var header = new byte[5];
                            if (stream.Read(header, 0, header.Length) != 5 || System.Text.Encoding.ASCII.GetString(header) != "%PDF-") throw new InvalidDataException("Plot device did not produce a PDF.");
                        }
                        File.Move(temp, job.Output);
                    }
                    finally { if (File.Exists(temp)) File.Delete(temp); }
                } });
            }
            BeginTasks(tasks, toFile && MergeJobCheck.IsChecked == true);
        }
        private void BeginTasks(List<CadTask> tasks, bool mergePdf = false)
        {
            string folder = Path.GetFullPath(FolderBox.Text.Trim());
            Directory.CreateDirectory(folder);
            // Verify report folder is writable before issuing irreversible physical print jobs.
            string probe = Path.Combine(folder, ".siraj-" + Guid.NewGuid().ToString("N"));
            using (File.Create(probe)) { } File.Delete(probe);
            MainTabs.IsEnabled = false; SharedPanel.IsEnabled = false; StopButton.IsEnabled = true;
            BatchProgress.Value = 0; lastJob = tasks.Select(t => t.Record).ToList();
            StatusText.Text = "Job queued. AutoCAD executes one sheet at a time; Stop takes effect between sheets.";
            runner.Start(tasks, (done, total) => { BatchProgress.Value = 100.0 * done / total; StatusText.Text = done + "/" + total + " processed"; }, () =>
            {
                MainTabs.IsEnabled = true; SharedPanel.IsEnabled = true; StopButton.IsEnabled = false;
                if (mergePdf)
                {
                    var mergeRecord = new JobRecord { Drawing = "PDF job", Layout = "Merge with bookmarks", Status = "Skipped" };
                    if (lastJob.All(r => r.Status == "Succeeded" || r.Status == "Skipped"))
                    {
                        try
                        {
                            string output = Path.Combine(folder, "SirajCAD_Issue_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".pdf");
                            PdfPublisher.Merge(lastJob.Select(r => r.Output).ToList(), output);
                            mergeRecord.Output = output; mergeRecord.Status = "Succeeded";
                        }
                        catch (Exception ex) { mergeRecord.Status = "Failed"; mergeRecord.Error = ex.Message; }
                    }
                    else mergeRecord.Error = "Merged issue not created because one or more sheets failed or were cancelled.";
                    lastJob.Add(mergeRecord);
                }
                foreach (var record in lastJob) logs.Add(record);
                LogGrid.Items.Refresh();
                string summary = string.Join(" • ", lastJob.GroupBy(r => r.Status).Select(g => g.Key + ": " + g.Count()));
                try { string report = Path.Combine(folder, "SirajCAD_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".csv"); ReportWriter.Save(report, lastJob); StatusText.Text = summary + " | Report: " + report; }
                catch (Exception ex) { StatusText.Text = summary + " | Report failed: " + ex.Message + ". Use Export job CSV to recover the log."; }
            });
        }
        private void StopBatch_Click(object sender, RoutedEventArgs e) { runner.Stop(); StatusText.Text = "Stop requested after current sheet."; }
        private void Frames_Click(object sender, RoutedEventArgs e) => Run(() => { FrameGrid.ItemsSource = CadTools.ScanFrames(FrameLayer.Text, Positive(UnitFactor.Text)); frameDocument = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument; });
        private void Recommend_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var row = FrameGrid.SelectedItem as FrameRow;
            if (row == null || row.Paper == "Custom") throw new InvalidOperationException("Select an ISO frame recommendation.");
            var media = CadEngine.GetMedia(DeviceBox.Text.Trim());
            string match = media.FirstOrDefault(m => m.IndexOf("ISO_" + row.Paper + "_", StringComparison.OrdinalIgnoreCase) >= 0);
            if (match == null) throw new InvalidOperationException("No exact ISO " + row.Paper + " canonical media in this device. Choose a size manually.");
            MediaPicker.Text = match; StatusText.Text = "Paper recommendation selected. Preview before applying.";
        });
        private void FrameLayout_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            if (!ReferenceEquals(frameDocument, Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument)) throw new InvalidOperationException("Drawing changed. Scan frames again.");
            var row = FrameGrid.SelectedItem as FrameRow;
            if (row == null) throw new InvalidOperationException("Select a model-space frame.");
            var name = Ask("New layout name", "Frame-" + row.Handle);
            if (name.Length == 0) return;
            CadTools.CreateFrameLayout(row, name, CurrentPreset(), Positive(FramePaperWidth.Text), Positive(FramePaperHeight.Text));
            Refresh(); StatusText.Text = "Created layout with fitted, locked viewport. Preview and verify paper area before plotting.";
        });
        private void Viewports_Click(object sender, RoutedEventArgs e) => Run(RefreshViewports);
        private void RefreshViewports() { ViewportGrid.ItemsSource = CadTools.Viewports(); viewportDocument = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument; }
        private void UpdateViewports(bool locked, double? scale)
        {
            if (!ReferenceEquals(viewportDocument, Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument)) throw new InvalidOperationException("Active drawing changed. Refresh viewports first.");
            var rows = ViewportGrid.SelectedItems.Cast<ViewportRow>().ToArray();
            if (rows.Length == 0) throw new InvalidOperationException("Select viewports first.");
            CadTools.SetViewports(rows, locked, scale); RefreshViewports();
        }
        private void Lock_Click(object sender, RoutedEventArgs e) => Run(() => UpdateViewports(true, null));
        private void Unlock_Click(object sender, RoutedEventArgs e) => Run(() => UpdateViewports(false, null));
        private void ViewportScale_Click(object sender, RoutedEventArgs e) => Run(() => UpdateViewports(true, Positive(ViewportScale.Text)));
        private void Quality_Click(object sender, RoutedEventArgs e) => Run(() => { QualityGrid.ItemsSource = CadTools.Inspect(); MainTabs.SelectedIndex = 8; });
        private void Process_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var files = drawings.ToList();
            if (files.Count == 0) throw new InvalidOperationException("Add DWG files first.");
            string folder = Path.GetFullPath(FolderBox.Text.Trim());
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var file in files) if (!names.Add(Path.GetFileNameWithoutExtension(file))) throw new InvalidOperationException("DWG names collide. Process same-name drawings in separate jobs.");
            if (MessageBox.Show(this, "Purge " + files.Count + " saved DWGs into new _clean.dwg copies? Unsaved changes are not included.", "Process copies", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            var tasks = files.Select(file =>
            {
                var record = new JobRecord { Drawing = file, Layout = "Purge", Output = Path.Combine(folder, Path.GetFileNameWithoutExtension(file) + "_clean.dwg"), Status = "Queued" };
                return new CadTask { Record = record, Work = () => { int count = CadTools.PurgeToCopy(file, folder); record.Layout = "Purge: " + count + " records removed"; } };
            }).ToList();
            BeginTasks(tasks);
        });
        private void ApplySettings()
        {
            FolderBox.Text = settings.OutputFolder; SkipExisting.IsChecked = settings.SkipExisting; NamingBox.SelectedIndex = settings.IncludeDrawingName ? 0 : 1; MergeJobCheck.IsChecked = settings.MergeAfterPublish;
            PresetList.ItemsSource = settings.Presets; PresetList.Items.Refresh();
        }
        private void SaveSettings()
        {
            if (!Path.IsPathRooted(FolderBox.Text.Trim())) throw new ArgumentException("Output folder must be absolute.");
            settings.OutputFolder = FolderBox.Text.Trim(); settings.SkipExisting = SkipExisting.IsChecked == true; settings.IncludeDrawingName = NamingBox.SelectedIndex == 0; settings.MergeAfterPublish = MergeJobCheck.IsChecked == true;
            XmlStore.Save(settingsFile, settings); StatusText.Text = "Settings saved: " + settingsFile;
        }
        private static void ValidateSettings(StudioSettings value)
        {
            if (value.Version != 1 || value.Presets == null || string.IsNullOrWhiteSpace(value.OutputFolder) || !Path.IsPathRooted(value.OutputFolder)) throw new InvalidDataException("Unsupported or incomplete settings file.");
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in value.Presets) { if (p == null) throw new InvalidDataException("Null preset."); p.Validate(); if (!names.Add(p.Name)) throw new InvalidDataException("Duplicate preset name."); }
        }
        private void Settings_Click(object sender, RoutedEventArgs e) => Run(SaveSettings);
        private void SavePreset_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var preset = CurrentPreset();
            var previous = settings.Presets.FirstOrDefault(p => p.Name.Equals(preset.Name, StringComparison.OrdinalIgnoreCase));
            if (previous != null && MessageBox.Show(this, "Replace preset " + preset.Name + "?", "Preset", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            if (previous != null) settings.Presets.Remove(previous);
            settings.Presets.Add(preset); SaveSettings(); ApplySettings();
        });
        private void LoadPreset_Click(object sender, RoutedEventArgs e) => Run(() =>
        {
            var p = PresetList.SelectedItem as PlotPreset;
            if (p == null) throw new InvalidOperationException("Select a saved preset.");
            p.Validate(); PresetName.Text = p.Name; DeviceBox.Text = p.Device; LoadMedia(); MediaPicker.Text = p.Media; StyleBox.Text = p.Style; FitCheck.IsChecked = p.Fit; LandscapeCheck.IsChecked = p.Landscape; PrintScale.Text = p.ScaleDenominator.ToString(CultureInfo.InvariantCulture);
        });
        private void DeletePreset_Click(object sender, RoutedEventArgs e) => Run(() => { var p = PresetList.SelectedItem as PlotPreset; if (p != null) { settings.Presets.Remove(p); SaveSettings(); ApplySettings(); } });
        private void ExportSettings_Click(object sender, RoutedEventArgs e) => Run(() => { SaveSettings(); var d = new SaveFileDialog { Filter = "SirajCAD settings|*.xml", FileName = "SirajCAD-settings.xml" }; if (d.ShowDialog(this) == true) XmlStore.Save(d.FileName, settings); });
        private void ImportSettings_Click(object sender, RoutedEventArgs e) => Run(() => { var d = new OpenFileDialog { Filter = "SirajCAD settings|*.xml" }; if (d.ShowDialog(this) != true) return; var imported = XmlStore.Load<StudioSettings>(d.FileName); ValidateSettings(imported); XmlStore.Save(settingsFile, imported); settings = imported; ApplySettings(); });
        private void AddPdfs_Click(object sender, RoutedEventArgs e) => Run(() => { var d = new OpenFileDialog { Filter = "PDF files|*.pdf", Multiselect = true }; if (d.ShowDialog(this) == true) foreach (string file in d.FileNames) pdfs.Add(file); });
        private void JobPdfs_Click(object sender, RoutedEventArgs e) => Run(() => { foreach (var r in lastJob.Where(r => r.Status == "Succeeded" && r.Output.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase) && File.Exists(r.Output))) if (!pdfs.Contains(r.Output)) pdfs.Add(r.Output); });
        private void MovePdf(int delta) { int index = PdfList.SelectedIndex; if (index < 0 || index + delta < 0 || index + delta >= pdfs.Count) return; pdfs.Move(index, index + delta); PdfList.SelectedIndex = index + delta; }
        private void PdfUp_Click(object sender, RoutedEventArgs e) => Run(() => MovePdf(-1));
        private void PdfDown_Click(object sender, RoutedEventArgs e) => Run(() => MovePdf(1));
        private void RemovePdf_Click(object sender, RoutedEventArgs e) => Run(() => { if (PdfList.SelectedIndex >= 0) pdfs.RemoveAt(PdfList.SelectedIndex); });
        private void Merge_Click(object sender, RoutedEventArgs e) => Run(() => { var d = new SaveFileDialog { Filter = "PDF document|*.pdf", FileName = "Project.pdf" }; if (d.ShowDialog(this) == true) { int pages = PdfPublisher.Merge(pdfs.ToList(), d.FileName); StatusText.Text = "Merged " + pages + " pages with file bookmarks: " + d.FileName; } });
        private void OpenPdf_Click(object sender, RoutedEventArgs e) => Run(() => { var file = PdfList.SelectedItem as string; if (file == null || !File.Exists(file) || !file.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) throw new FileNotFoundException("Select an existing PDF."); Process.Start(new ProcessStartInfo(file) { UseShellExecute = true }); });
        private void ExportLog_Click(object sender, RoutedEventArgs e) => Run(() => { var d = new SaveFileDialog { Filter = "CSV report|*.csv", FileName = "SirajCAD-report.csv" }; if (d.ShowDialog(this) == true) ReportWriter.Save(d.FileName, logs); });
    }
}
