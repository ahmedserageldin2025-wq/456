using System;
using System.Collections.Generic;
using SirajCAD.Core;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace SirajCAD.PlotStudio
{
    internal sealed class CadTask : BatchTask { }
    // No Task.Run, dispatcher pumping or background access to AutoCAD databases.
    internal sealed class CadJobRunner
    {
        private BatchSession session;
        private bool executing;
        private Action<int, int> progress;
        private Action complete;
        public bool IsRunning => session != null && session.IsRunning;
        public void Start(IList<CadTask> work, Action<int, int> onProgress, Action onComplete)
        {
            if (IsRunning) throw new InvalidOperationException("A job is already running.");
            session = new BatchSession(work); progress = onProgress; complete = onComplete;
            AcApp.Idle += Tick;
        }
        public void Stop() { session?.Stop(); }
        private void Tick(object sender, EventArgs args)
        {
            if (!IsRunning || executing || !AcApp.DocumentManager.IsApplicationContext) return;
            executing = true;
            try { session.Step(); progress?.Invoke(session.CompletedCount, session.TotalCount); }
            finally
            {
                executing = false;
                if (!IsRunning)
                {
                    AcApp.Idle -= Tick;
                    complete?.Invoke();
                }
            }
        }
    }
}
