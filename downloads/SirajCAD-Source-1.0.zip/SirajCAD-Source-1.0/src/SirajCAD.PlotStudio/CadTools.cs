using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using SirajCAD.Core;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace SirajCAD.PlotStudio
{
    public sealed class FrameRow
    {
        public string Handle { get; set; }
        public string Layer { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public string Paper { get; set; }
        public string Kind { get; set; }
    }
    public sealed class ViewportRow
    {
        public string Handle { get; set; }
        public string Layout { get; set; }
        public int Number { get; set; }
        public bool Locked { get; set; }
        public double Scale { get; set; }
    }
    public sealed class QualityIssue
    {
        public string Severity { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
    }
    public static class CadTools
    {
        private static Document Active => AcApp.DocumentManager.MdiActiveDocument ?? throw new InvalidOperationException("Open a DWG first.");
        public static List<FrameRow> ScanFrames(string layer, double unitToMm)
        {
            if (unitToMm <= 0 || double.IsNaN(unitToMm) || double.IsInfinity(unitToMm)) throw new ArgumentException("Drawing-unit to millimetre factor must be positive.");
            var doc = Active;
            var result = new List<FrameRow>();
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                var space = (BlockTableRecord)tr.GetObject(doc.Database.CurrentSpaceId, OpenMode.ForRead);
                foreach (ObjectId id in space)
                {
                    var entity = tr.GetObject(id, OpenMode.ForRead) as Entity;
                    if (entity == null || (!string.IsNullOrWhiteSpace(layer) && !entity.Layer.Equals(layer, StringComparison.OrdinalIgnoreCase))) continue;
                    var poly = entity as Polyline;
                    var block = entity as BlockReference;
                    // Closed orthogonal, four-corner polylines; block extents are candidates, never asserted to be title blocks.
                    if (poly != null && IsRectangle(poly) || block != null)
                    {
                        try
                        {
                            var bounds = entity.GeometricExtents;
                            double w = (bounds.MaxPoint.X - bounds.MinPoint.X) * unitToMm;
                            double h = (bounds.MaxPoint.Y - bounds.MinPoint.Y) * unitToMm;
                            if (w <= 0 || h <= 0) continue;
                            result.Add(new FrameRow { Handle = entity.Handle.ToString(), Layer = entity.Layer, Width = w, Height = h, Paper = SheetGeometry.RecommendIso(w, h), Kind = block == null ? "Rectangle" : "Block bounds (candidate)" });
                        }
                        catch (Autodesk.AutoCAD.Runtime.Exception) { /* Entities without geometric extents are not frame candidates. */ }
                    }
                }
            }
            return result;
        }
        private static bool IsRectangle(Polyline p)
        {
            if (!p.Closed || p.NumberOfVertices != 4) return false;
            var vectors = new List<Vector2d>();
            for (int i = 0; i < 4; i++)
            {
                if (Math.Abs(p.GetBulgeAt(i)) > 1e-9) return false;
                var v = p.GetPoint2dAt((i + 1) % 4) - p.GetPoint2dAt(i);
                if (v.Length < 1e-8) return false;
                vectors.Add(v.GetNormal());
            }
            return Enumerable.Range(0, 4).All(i => Math.Abs(vectors[i].DotProduct(vectors[(i + 1) % 4])) < 1e-6);
        }
        public static void CreateFrameLayout(FrameRow frame, string name, PlotPreset preset, double paperWidth, double paperHeight)
        {
            if (frame == null) throw new ArgumentException("Select a frame first.");
            if (string.IsNullOrWhiteSpace(name) || name.IndexOfAny("<>/\\\":;?*|,=`".ToCharArray()) >= 0) throw new ArgumentException("Invalid layout name.");
            if (paperWidth <= 0 || paperHeight <= 0) throw new ArgumentException("Viewport paper dimensions must be positive.");
            var doc = Active;
            using (doc.LockDocument())
            {
                var manager = LayoutManager.Current;
                string previous = manager.CurrentLayout;
                ObjectId created = ObjectId.Null;
                try
                {
                    // Verify the candidate still exists in model space before creating a new layout.
                    Extents3d bounds;
                    using (var tr = doc.Database.TransactionManager.StartTransaction())
                    {
                        var blocks = (BlockTable)tr.GetObject(doc.Database.BlockTableId, OpenMode.ForRead);
                        var id = doc.Database.GetObjectId(false, new Handle(Convert.ToInt64(frame.Handle, 16)), 0);
                        var entity = (Entity)tr.GetObject(id, OpenMode.ForRead);
                        if (entity.OwnerId != blocks[BlockTableRecord.ModelSpace]) throw new InvalidOperationException("Frame-to-layout creation requires a model-space entity.");
                        bounds = entity.GeometricExtents;
                    }
                    created = manager.CreateLayout(name);
                    using (var tr = doc.Database.TransactionManager.StartTransaction())
                    {
                        var layout = (Layout)tr.GetObject(created, OpenMode.ForWrite);
                        CadEngine.Configure(layout, preset);
                        var space = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForWrite);
                        foreach (ObjectId id in space)
                        {
                            var old = tr.GetObject(id, OpenMode.ForRead) as Viewport;
                            if (old != null && old.Number != 1) { old.UpgradeOpen(); old.Erase(); }
                        }
                        var layers = (LayerTable)tr.GetObject(doc.Database.LayerTableId, OpenMode.ForRead);
                        const string layerName = "SIRAJ_VIEWPORTS";
                        if (!layers.Has(layerName))
                        {
                            layers.UpgradeOpen();
                            var layer = new LayerTableRecord { Name = layerName, IsPlottable = false };
                            layers.Add(layer); tr.AddNewlyCreatedDBObject(layer, true);
                        }
                        else if (((LayerTableRecord)tr.GetObject(layers[layerName], OpenMode.ForRead)).IsPlottable) throw new InvalidOperationException("SIRAJ_VIEWPORTS layer exists and is plottable. Use a drawing with a non-plot viewport layer.");
                        var vp = new Viewport();
                        vp.SetDatabaseDefaults(doc.Database);
                        space.AppendEntity(vp); tr.AddNewlyCreatedDBObject(vp, true);
                        vp.Layer = layerName;
                        vp.Width = paperWidth; vp.Height = paperHeight;
                        vp.CenterPoint = new Point3d(paperWidth / 2, paperHeight / 2, 0);
                        vp.ViewDirection = Vector3d.ZAxis; vp.ViewTarget = Point3d.Origin;
                        vp.ViewCenter = new Point2d((bounds.MinPoint.X + bounds.MaxPoint.X) / 2, (bounds.MinPoint.Y + bounds.MaxPoint.Y) / 2);
                        vp.ViewHeight = Math.Max(bounds.MaxPoint.Y - bounds.MinPoint.Y, (bounds.MaxPoint.X - bounds.MinPoint.X) * paperHeight / paperWidth) * 1.02;
                        vp.On = true; vp.Locked = true;
                        tr.Commit();
                    }
                }
                catch
                {
                    if (!created.IsNull) manager.DeleteLayout(name);
                    throw;
                }
                finally { manager.CurrentLayout = previous; }
            }
        }
        public static List<ViewportRow> Viewports()
        {
            var doc = Active;
            var rows = new List<ViewportRow>();
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                var layouts = (DBDictionary)tr.GetObject(doc.Database.LayoutDictionaryId, OpenMode.ForRead);
                foreach (DBDictionaryEntry entry in layouts)
                {
                    var layout = (Layout)tr.GetObject(entry.Value, OpenMode.ForRead);
                    if (layout.ModelType) continue;
                    var space = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForRead);
                    foreach (ObjectId id in space)
                    {
                        var vp = tr.GetObject(id, OpenMode.ForRead) as Viewport;
                        if (vp == null || vp.Number == 1) continue;
                        rows.Add(new ViewportRow { Handle = vp.Handle.ToString(), Layout = layout.LayoutName, Number = vp.Number, Locked = vp.Locked, Scale = vp.CustomScale });
                    }
                }
            }
            return rows;
        }
        public static void SetViewports(IEnumerable<ViewportRow> selected, bool locked, double? denominator)
        {
            if (denominator.HasValue && (denominator <= 0 || double.IsNaN(denominator.Value) || double.IsInfinity(denominator.Value))) throw new ArgumentException("Scale must be positive.");
            var doc = Active;
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                foreach (var row in selected)
                {
                    var id = doc.Database.GetObjectId(false, new Handle(Convert.ToInt64(row.Handle, 16)), 0);
                    var vp = tr.GetObject(id, OpenMode.ForWrite) as Viewport;
                    if (vp == null || vp.Number == 1) throw new InvalidOperationException("Invalid viewport selection. Refresh the list.");
                    vp.Locked = false;
                    if (denominator.HasValue) vp.CustomScale = 1.0 / denominator.Value;
                    vp.Locked = locked;
                }
                tr.Commit();
            }
            doc.Editor.Regen();
        }
        public static List<QualityIssue> Inspect()
        {
            var doc = Active;
            var issues = new List<QualityIssue>();
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                var layouts = (DBDictionary)tr.GetObject(doc.Database.LayoutDictionaryId, OpenMode.ForRead);
                var devices = CadEngine.GetPlotDevices();
                foreach (DBDictionaryEntry entry in layouts)
                {
                    var l = (Layout)tr.GetObject(entry.Value, OpenMode.ForRead);
                    if (l.ModelType) continue;
                    if (string.IsNullOrEmpty(l.PlotConfigurationName) || !devices.Contains(l.PlotConfigurationName)) issues.Add(new QualityIssue { Severity = "Error", Subject = l.LayoutName, Message = "Plot device is unavailable: " + l.PlotConfigurationName });
                    if (string.IsNullOrEmpty(l.CanonicalMediaName)) issues.Add(new QualityIssue { Severity = "Warning", Subject = l.LayoutName, Message = "No canonical paper size assigned." });
                }
                var blocks = (BlockTable)tr.GetObject(doc.Database.BlockTableId, OpenMode.ForRead);
                foreach (ObjectId id in blocks)
                {
                    var b = (BlockTableRecord)tr.GetObject(id, OpenMode.ForRead);
                    if (b.IsFromExternalReference && b.XrefStatus != XrefStatus.Resolved) issues.Add(new QualityIssue { Severity = "Warning", Subject = b.Name, Message = "Xref status: " + b.XrefStatus });
                }
            }
            foreach (var vp in Viewports().Where(v => !v.Locked)) issues.Add(new QualityIssue { Severity = "Warning", Subject = vp.Layout + "/" + vp.Handle, Message = "Viewport scale is unlocked." });
            if (issues.Count == 0) issues.Add(new QualityIssue { Severity = "Info", Subject = doc.Name, Message = "No issues found by device, media assignment, xref status and viewport-lock checks. This is not a DWG integrity audit." });
            return issues;
        }
        public static int PurgeToCopy(string input, string outputFolder)
        {
            if (!File.Exists(input)) throw new FileNotFoundException("DWG not found", input);
            Directory.CreateDirectory(outputFolder);
            string output = Path.Combine(outputFolder, Path.GetFileNameWithoutExtension(input) + "_clean.dwg");
            if (File.Exists(output) || string.Equals(Path.GetFullPath(input), Path.GetFullPath(output), StringComparison.OrdinalIgnoreCase)) throw new IOException("Refusing to overwrite drawing: " + output);
            using (var db = new Database(false, true))
            {
                db.ReadDwgFile(input, FileShare.Read, true, "");
                db.CloseInput(true);
                int removed = 0;
                // Multiple passes remove dependent unused records. Purge protects referenced symbols.
                for (int pass = 0; pass < 10; pass++)
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    var candidates = new ObjectIdCollection();
                    foreach (var tableId in new[] { db.BlockTableId, db.LayerTableId, db.LinetypeTableId, db.TextStyleTableId, db.DimStyleTableId, db.RegAppTableId })
                    {
                        var table = (SymbolTable)tr.GetObject(tableId, OpenMode.ForRead);
                        foreach (ObjectId id in table) candidates.Add(id);
                    }
                    db.Purge(candidates);
                    if (candidates.Count == 0) break;
                    foreach (ObjectId id in candidates) { tr.GetObject(id, OpenMode.ForWrite).Erase(); removed++; }
                    tr.Commit();
                }
                string temp = Path.Combine(outputFolder, Guid.NewGuid().ToString("N") + ".dwg");
                try { db.SaveAs(temp, DwgVersion.AC1032); File.Move(temp, output); }
                finally { if (File.Exists(temp)) File.Delete(temp); }
                return removed;
            }
        }
    }
}
