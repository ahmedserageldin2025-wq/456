using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.PlottingServices;
using System.Windows;
using System.IO;
using System.Linq;
using System;
using System.Collections.Generic;
using SirajCAD.Core;
using PlotType = Autodesk.AutoCAD.DatabaseServices.PlotType;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

[assembly: ExtensionApplication(typeof(SirajCAD.PlotStudio.Plugin))]
[assembly: CommandClass(typeof(SirajCAD.PlotStudio.Plugin))]
namespace SirajCAD.PlotStudio
{

public class Plugin : IExtensionApplication
{
    private static StudioWindow window;
    public void Initialize() { }
    public void Terminate() { if (window != null) window.Close(); window = null; }

    [CommandMethod("SIRAJ_PLOT", CommandFlags.Session)]
    public void OpenStudio()
    {
        if (window != null && window.IsVisible) { window.Activate(); return; }
        window = new StudioWindow();
        window.Closed += (s, e) => window = null;
        AcApp.ShowModelessWindow(window);
    }
}

public class SheetRow
{
 public string Name { get; set; }
 public int Order { get; set; }
 public bool IsModel { get; set; }
 public SheetRow(string name, int order, bool model) { Name=name; Order=order; IsModel=model; }
}

public static class CadEngine
{
    private static Document Doc { get { var d=AcApp.DocumentManager.MdiActiveDocument; if (d==null) throw new InvalidOperationException("Open a DWG drawing first."); return d; } }

    public static List<SheetRow> GetSheets()
    {
        var doc = Doc;
        using var docLock = doc.LockDocument();
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var dict = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
        var rows = new List<SheetRow>();
        foreach (DBDictionaryEntry entry in dict)
        {
            var l = (Layout)tr.GetObject(entry.Value, OpenMode.ForRead);
            rows.Add(new SheetRow(l.LayoutName, l.TabOrder, l.ModelType));
        }
        return rows.OrderBy(x => x.IsModel ? -1 : x.Order).ToList();
    }

    public static void CreateLayout(string name)
    {
        ValidateName(name);
        var doc = Doc;
        using (doc.LockDocument()) Autodesk.AutoCAD.DatabaseServices.LayoutManager.Current.CreateLayout(name);
    }
    public static void CloneLayout(string source, string destination)
    {
        ValidateName(destination);
        var doc = Doc;
        using (doc.LockDocument()) Autodesk.AutoCAD.DatabaseServices.LayoutManager.Current.CopyLayout(source, destination);
    }
    public static void RenameLayout(string oldName, string newName)
    {
        ValidateName(newName);
        if (oldName.Equals("Model", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Model cannot be renamed.");
        var doc = Doc;
        using (doc.LockDocument()) Autodesk.AutoCAD.DatabaseServices.LayoutManager.Current.RenameLayout(oldName, newName);
    }
    public static void DeleteLayout(string name)
    {
        if (name.Equals("Model", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Model cannot be deleted.");
        var doc = Doc;
        using (doc.LockDocument()) Autodesk.AutoCAD.DatabaseServices.LayoutManager.Current.DeleteLayout(name);
    }
    public static void MoveLayout(string name, int offset)
    {
        if (name == "Model") return;
        var doc = Doc;
        using (doc.LockDocument())
        {
            var db = doc.Database;
            using var tr = db.TransactionManager.StartTransaction();
            var dict = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
            var ordered = dict.Cast<DBDictionaryEntry>()
                .Select(e => (Layout)tr.GetObject(e.Value, OpenMode.ForWrite))
                .Where(l => !l.ModelType).OrderBy(l => l.TabOrder).ToList();
            var idx = ordered.FindIndex(l => l.LayoutName == name);
            if (idx < 0 || idx + offset < 0 || idx + offset >= ordered.Count) return;
            var temp=ordered[idx]; ordered[idx]=ordered[idx+offset]; ordered[idx+offset]=temp;
            for (int i = 0; i < ordered.Count; i++) ordered[i].TabOrder = i + 1;
            tr.Commit();
        }
    }
    public static void SetCurrentLayout(string layoutName)
    {
        var doc=Doc;
        using (doc.LockDocument()) Autodesk.AutoCAD.DatabaseServices.LayoutManager.Current.CurrentLayout=layoutName;
    }
    public static string[] ListLayoutsForFile(string path)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("Drawing file not found",path);
        using (var db=new Database(false,true))
        {
            db.ReadDwgFile(path,FileShare.Read,true,"");
            using(var tr=db.TransactionManager.StartTransaction())
            {
                var dict=(DBDictionary)tr.GetObject(db.LayoutDictionaryId,OpenMode.ForRead);
                return dict.Cast<DBDictionaryEntry>().Select(e=>(Layout)tr.GetObject(e.Value,OpenMode.ForRead)).Where(l=>!l.ModelType).OrderBy(l=>l.TabOrder).Select(l=>l.LayoutName).ToArray();
            }
        }
    }
    public static List<string> GetPlotDevices()
    {
        var doc = Doc;
        using (doc.LockDocument())
        using (var tr = doc.Database.TransactionManager.StartTransaction())
        {
            var dict = (DBDictionary)tr.GetObject(doc.Database.LayoutDictionaryId, OpenMode.ForRead);
            var layout = (Layout)tr.GetObject(dict.GetAt(LayoutManager.Current.CurrentLayout), OpenMode.ForRead);
            using (var ps = new PlotSettings(layout.ModelType))
            {
                ps.CopyFrom(layout);
                PlotSettingsValidator.Current.RefreshLists(ps);
                return PlotSettingsValidator.Current.GetPlotDeviceList().Cast<string>().OrderBy(x => x).ToList();
            }
        }
    }

    public static List<string> GetMedia(string device)
    {
        var doc = Doc;
        using (doc.LockDocument())
        using (var tr = doc.Database.TransactionManager.StartTransaction())
        {
            var dict = (DBDictionary)tr.GetObject(doc.Database.LayoutDictionaryId, OpenMode.ForRead);
            var layout = (Layout)tr.GetObject(dict.GetAt(LayoutManager.Current.CurrentLayout), OpenMode.ForRead);
            using (var ps = new PlotSettings(layout.ModelType))
            {
                ps.CopyFrom(layout);
                var validator = PlotSettingsValidator.Current;
                validator.SetPlotConfigurationName(ps, device, null);
                validator.RefreshLists(ps);
                return validator.GetCanonicalMediaNameList(ps).Cast<string>().OrderBy(x => x).ToList();
            }
        }
    }

    public static string CurrentDocumentFile()
    {
        return Doc.Name;
    }

    private static void ValidateName(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.IndexOfAny("<>/\\\":;?*|,=`".ToCharArray()) >= 0)
            throw new ArgumentException("Enter a valid layout name.");
    }

    public static void PlotSheet(string layoutName, string output, PlotPreset preset, bool toFile, bool preview)
    {
        preset.Validate();
        var doc = Doc;
        if (PlotFactory.ProcessPlotState != ProcessPlotState.NotPlotting) throw new InvalidOperationException("AutoCAD is already plotting.");
        if (toFile && !preview)
        {
            if (File.Exists(output)) throw new IOException("Output exists: " + output);
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output)));
        }
        string previous = LayoutManager.Current.CurrentLayout;
        object background = AcApp.GetSystemVariable("BACKGROUNDPLOT");
        using (doc.LockDocument())
        try
        {
            AcApp.SetSystemVariable("BACKGROUNDPLOT", 0);
            LayoutManager.Current.CurrentLayout = layoutName;
            var db = doc.Database;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var layouts = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
                if (!layouts.Contains(layoutName)) throw new InvalidOperationException("Layout does not exist: " + layoutName);
                var layout = (Layout)tr.GetObject(layouts.GetAt(layoutName), OpenMode.ForRead);
                using (var settings = new PlotSettings(layout.ModelType))
                using (var pi = new PlotInfo())
                using (var validator = new PlotInfoValidator())
                {
                    settings.CopyFrom(layout);
                    Configure(settings, preset);
                    pi.Layout = layout.ObjectId; pi.OverrideSettings = settings;
                    validator.MediaMatchingPolicy = MatchingPolicy.MatchDisabled;
                    validator.Validate(pi);
                    using (var engine = preview ? PlotFactory.CreatePreviewEngine((int)PreviewEngineFlags.Plot) : PlotFactory.CreatePublishEngine())
                    using (var page = new PlotPageInfo())
                    {
                        engine.BeginPlot(null, null);
                        engine.BeginDocument(pi, db.Filename, null, 1, toFile, output ?? "");
                        engine.BeginPage(page, pi, true, null);
                        engine.BeginGenerateGraphics(null);
                        engine.EndGenerateGraphics(null);
                        if (preview)
                        {
                            using (var end = new PreviewEndPlotInfo()) engine.EndPage(end);
                        }
                        else engine.EndPage(null);
                        engine.EndDocument(null);
                        engine.EndPlot(null);
                    }
                }
            }
        }
        finally
        {
            try { LayoutManager.Current.CurrentLayout = previous; }
            finally { AcApp.SetSystemVariable("BACKGROUNDPLOT", background); }
        }
    }
    public static void Configure(PlotSettings settings, PlotPreset preset)
    {
        preset.Validate();
        var psv = PlotSettingsValidator.Current;
        psv.SetPlotConfigurationName(settings, preset.Device, null);
        psv.RefreshLists(settings);
        if (!string.IsNullOrWhiteSpace(preset.Media)) psv.SetCanonicalMediaName(settings, preset.Media);
        psv.SetPlotType(settings, settings.ModelType || preset.Fit ? PlotType.Extents : PlotType.Layout);
        psv.SetPlotRotation(settings, preset.Landscape ? PlotRotation.Degrees090 : PlotRotation.Degrees000);
        psv.SetUseStandardScale(settings, preset.Fit);
        if (preset.Fit) psv.SetStdScaleType(settings, StdScaleType.ScaleToFit);
        else psv.SetCustomPrintScale(settings, new CustomScale(1, preset.ScaleDenominator));
        if (settings.ModelType || preset.Fit) psv.SetPlotCentered(settings, true);
        if (!string.IsNullOrWhiteSpace(preset.Style)) psv.SetCurrentStyleSheet(settings, preset.Style);
    }
    public static void ApplyPreset(string layoutName, PlotPreset preset)
    {
        var doc = Doc;
        using (doc.LockDocument())
        using (var tr = doc.Database.TransactionManager.StartTransaction())
        {
            var layouts = (DBDictionary)tr.GetObject(doc.Database.LayoutDictionaryId, OpenMode.ForRead);
            var layout = (Layout)tr.GetObject(layouts.GetAt(layoutName), OpenMode.ForWrite);
            Configure(layout, preset);
            tr.Commit();
        }
    }
    public static void PlotExternalSheet(string file, string layout, string output, PlotPreset preset, bool toFile)
    {
        var manager = AcApp.DocumentManager;
        var previous = manager.MdiActiveDocument;
        Document source = null;
        bool opened = false;
        try
        {
            foreach (Document candidate in manager)
                if (string.Equals(Path.GetFullPath(candidate.Name), Path.GetFullPath(file), StringComparison.OrdinalIgnoreCase)) { source = candidate; break; }
            if (source == null) { source = manager.Open(file, true); opened = true; }
            manager.MdiActiveDocument = source;
            PlotSheet(layout, output, preset, toFile, false);
        }
        finally
        {
            try { if (opened && source != null) source.CloseAndDiscard(); }
            finally { if (previous != null) manager.MdiActiveDocument = previous; }
        }
    }
}
}
