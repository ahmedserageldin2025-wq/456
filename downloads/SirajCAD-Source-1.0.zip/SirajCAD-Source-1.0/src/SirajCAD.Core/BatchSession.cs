using System;
using System.Collections.Generic;
using System.Linq;

namespace SirajCAD.Core
{
    public class BatchTask
    {
        public JobRecord Record { get; set; }
        public Action Work { get; set; }
        public Action<string> SetStatus { get; set; }
    }
    // Host-independent state machine; the AutoCAD adapter calls Step only on its host thread.
    public sealed class BatchSession
    {
        private readonly BatchTask[] tasks;
        private bool stepping;
        private bool stop;
        public bool IsRunning { get; private set; } = true;
        public int CompletedCount { get; private set; }
        public int TotalCount => tasks.Length;
        public BatchSession(IEnumerable<BatchTask> work)
        {
            tasks = work.ToArray();
            if (tasks.Length == 0 || tasks.Any(t => t == null || t.Record == null || t.Work == null)) throw new ArgumentException("A batch requires valid tasks.");
        }
        public void Stop() { stop = true; }
        public void Step()
        {
            if (!IsRunning || stepping) return;
            stepping = true;
            try
            {
                if (stop)
                {
                    while (CompletedCount < tasks.Length)
                    {
                        var task = tasks[CompletedCount++];
                        task.Record.Status = "Cancelled"; task.SetStatus?.Invoke("Cancelled");
                    }
                }
                else
                {
                    var task = tasks[CompletedCount++];
                    task.Record.Utc = DateTime.UtcNow;
                    task.Record.Status = "Running";
                    try
                    {
                        task.SetStatus?.Invoke("Running");
                        task.Work();
                        if (task.Record.Status == "Running") task.Record.Status = "Succeeded";
                    }
                    catch (Exception ex) { task.Record.Status = "Failed"; task.Record.Error = ex.Message; }
                    task.SetStatus?.Invoke(task.Record.Status);
                }
            }
            finally { stepping = false; IsRunning = CompletedCount < tasks.Length; }
        }
    }
}
