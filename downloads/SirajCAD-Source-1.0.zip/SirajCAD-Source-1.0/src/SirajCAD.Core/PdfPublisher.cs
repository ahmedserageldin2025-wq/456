using System;
using System.Collections.Generic;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace SirajCAD.Core
{
    public static class PdfPublisher
    {
        public static int Merge(IList<string> inputs, string destination)
        {
            if (inputs == null || inputs.Count == 0) throw new ArgumentException("Select PDFs to merge.");
            destination = Path.GetFullPath(destination);
            if (File.Exists(destination)) throw new IOException("Destination already exists.");
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            string temp = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                int count = 0;
                using (var merged = new PdfDocument())
                {
                    merged.Info.Title = "SirajCAD Plot Studio";
                    foreach (string file in inputs)
                    {
                        using (var input = PdfReader.Open(file, PdfDocumentOpenMode.Import))
                        {
                            PdfPage first = null;
                            for (int i = 0; i < input.PageCount; i++)
                            {
                                var page = merged.AddPage(input.Pages[i]);
                                if (first == null) first = page;
                                count++;
                            }
                            if (first != null) merged.Outlines.Add(Path.GetFileNameWithoutExtension(file), first, true);
                        }
                    }
                    if (count == 0) throw new InvalidDataException("Input contains no pages.");
                    merged.Save(temp);
                }
                File.Move(temp, destination);
                return count;
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
}
