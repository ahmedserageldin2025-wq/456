using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SirajCAD.Core
{
    public class PlotPreset
    {
        public string Name { get; set; } = "Default";
        public string Device { get; set; } = "DWG To PDF.pc3";
        public string Media { get; set; } = "";
        public string Style { get; set; } = "monochrome.ctb";
        public bool Fit { get; set; } = true;
        public bool Landscape { get; set; }
        public double ScaleDenominator { get; set; } = 1;
        public void Validate()
        {
            if (string.IsNullOrWhiteSpace(Name) || string.IsNullOrWhiteSpace(Device)) throw new ArgumentException("Preset name and plot device are required.");
            if (double.IsNaN(ScaleDenominator) || double.IsInfinity(ScaleDenominator) || ScaleDenominator <= 0) throw new ArgumentException("Scale denominator must be a finite positive number.");
        }
    }
    public class StudioSettings
    {
        public int Version { get; set; } = 1;
        public string OutputFolder { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SirajCAD PDFs");
        public bool SkipExisting { get; set; } = true;
        public bool IncludeDrawingName { get; set; } = true;
        public bool MergeAfterPublish { get; set; }
        public List<PlotPreset> Presets { get; set; } = new List<PlotPreset>();
    }
    public static class XmlStore
    {
        public static T Load<T>(string path) where T : new()
        {
            if (!File.Exists(path)) return new T();
            // Corrupt files are reported, never silently overwritten with defaults.
            using (var reader = System.Xml.XmlReader.Create(path, new System.Xml.XmlReaderSettings { DtdProcessing = System.Xml.DtdProcessing.Prohibit, XmlResolver = null }))
                return (T)new XmlSerializer(typeof(T)).Deserialize(reader);
        }
        public static void Save<T>(string path, T value)
        {
            path = Path.GetFullPath(path);
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) new XmlSerializer(typeof(T)).Serialize(stream, value);
                if (File.Exists(path)) File.Replace(temp, path, path + ".bak");
                else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
    public sealed class SheetJob
    {
        public string Drawing { get; set; }
        public string Layout { get; set; }
        public string Output { get; set; }
    }
    public static class JobPlanner
    {
        // Explicit Windows rules: planning and tests behave identically on Linux and Windows.
        public static string SafeName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("A file name is required.");
            const string invalid = "<>:\"/\\|?*";
            string clean = new string(value.Select(c => c < 32 || invalid.IndexOf(c) >= 0 ? '_' : c).ToArray()).Trim().TrimEnd('.', ' ');
            if (clean.Length == 0) clean = "Sheet";
            string stem = clean.Split('.')[0].ToUpperInvariant();
            if (new[] { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" }.Contains(stem)) clean = "_" + clean;
            if (clean.Length > 120) clean = clean.Substring(0, 120).TrimEnd('.', ' ');
            return clean;
        }
        public static List<SheetJob> Plan(IEnumerable<SheetJob> source, string folder, bool includeDrawing)
        {
            if (string.IsNullOrWhiteSpace(folder) || !Path.IsPathRooted(folder)) throw new ArgumentException("Choose an absolute output folder.");
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var jobs = new List<SheetJob>();
            foreach (var item in source)
            {
                if (string.IsNullOrWhiteSpace(item.Drawing) || string.IsNullOrWhiteSpace(item.Layout)) throw new ArgumentException("Every sheet needs a drawing and layout.");
                string stem = SafeName((includeDrawing ? Path.GetFileNameWithoutExtension(item.Drawing) + "_" : "") + item.Layout);
                string output = Path.Combine(folder, stem + ".pdf");
                if (!used.Add(output)) throw new InvalidOperationException("Output name collision: " + output + ". Use distinct drawing/layout names or separate jobs.");
                jobs.Add(new SheetJob { Drawing = item.Drawing, Layout = item.Layout, Output = output });
            }
            if (jobs.Count == 0) throw new InvalidOperationException("Select at least one sheet.");
            return jobs;
        }
    }
    public class JobRecord
    {
        public DateTime Utc { get; set; } = DateTime.UtcNow;
        public string Drawing { get; set; }
        public string Layout { get; set; }
        public string Status { get; set; }
        public string Output { get; set; }
        public string Error { get; set; }
    }
    public static class ReportWriter
    {
        private static string Cell(string value)
        {
            value = value ?? "";
            // Spreadsheet formulas must not execute when a DWG/layout name is opened in Excel.
            if (value.TrimStart().Length > 0 && "=+-@".IndexOf(value.TrimStart()[0]) >= 0) value = "'" + value;
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }
        public static void Save(string path, IEnumerable<JobRecord> records)
        {
            using (var writer = new StreamWriter(path, false, new UTF8Encoding(true)))
            {
                writer.WriteLine("UTC,Drawing,Layout,Status,Output,Error");
                foreach (var row in records) writer.WriteLine(string.Join(",", new[] { row.Utc.ToString("O", CultureInfo.InvariantCulture), row.Drawing, row.Layout, row.Status, row.Output, row.Error }.Select(Cell)));
            }
        }
    }
    public static class SheetGeometry
    {
        public static string RecommendIso(double widthMm, double heightMm)
        {
            if (widthMm <= 0 || heightMm <= 0 || double.IsNaN(widthMm + heightMm) || double.IsInfinity(widthMm + heightMm)) throw new ArgumentException("Frame dimensions must be finite positive millimetres.");
            double shortSide = Math.Min(widthMm, heightMm), longSide = Math.Max(widthMm, heightMm);
            var sizes = new[] { new { N="A4", W=210d,H=297d }, new { N="A3",W=297d,H=420d }, new { N="A2",W=420d,H=594d }, new { N="A1",W=594d,H=841d }, new { N="A0",W=841d,H=1189d } };
            return sizes.FirstOrDefault(s => shortSide <= s.W + 1 && longSide <= s.H + 1)?.N ?? "Custom";
        }
    }
}
